/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

/* global artyom, PF */

var artyom = new Artyom();
var UserDictation;
var textoDictado = "";

function prenderMicrofono() {
    console.log("INICIANDO...");
    artyom.fatality();// Detener cualquier instancia previa

    artyom.initialize({
        lang: "es-ES", // Más lenguajes son soportados, lee la documentación
        continuous: true, // Reconoce 1 solo comando y basta de escuchar
        listen: true, // Iniciar !
        debug: false, // Muestra un informe en la consola
        speed: 1,
        executionKeyword: "escucha"// Habla normalmente
    }).then(function () {
        console.log("Ready to work !");
    });

    UserDictation = artyom.newDictation({
        continuous: true, // Activar modo continuous if HTTPS connection
        onResult: function (text) {
            if(text !== ""){
                textoDictado = text;
            // Mostrar texto en consola
            console.log(text);   
            }
        },
        onStart: function () {
            console.log("Dictado iniciado");
        },
        onEnd: function () {
            //alert("Dictado detenido por el usuario");
            console.log("Dictado detenido por el usuario");
        }
    });
    UserDictation.start();

}

function cancelarEscuchaComandosVoz() {
    console.log("DETENIENDO...");
    console.log(textoDictado);
    document.getElementById("frmTraductor:textraductor").value = removeAccents(textoDictado);
    //PF('textotradu').jq.val( textoDictado );
    
    artyom.fatality();// Detener cualquier instancia previa
    UserDictation.stop();
}

const removeAccents = (str) => {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}; 



