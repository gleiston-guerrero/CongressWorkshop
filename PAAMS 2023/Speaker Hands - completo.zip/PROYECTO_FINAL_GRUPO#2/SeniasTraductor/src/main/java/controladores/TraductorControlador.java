/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package controladores;

import entidades.SeniasPalabras;
import facade.SeniasPalabrasFacade;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;

/**
 *
 * @author pc
 */
@Named(value = "traductorControlador")
@ViewScoped
public class TraductorControlador implements Serializable {

    @EJB
    private SeniasPalabrasFacade seniasPalabrasFacade;

    private String textoATraducir = "";
    private List<SeniasPalabras> seniasPalabras;
    private SeniasPalabras seniaPalabra;

    /**
     * Creates a new instance of TraductorControlador
     */
    public TraductorControlador() {
    }

    @PostConstruct
    public void init() {
        this.seniasPalabras = new ArrayList();
    }

    public void traducir() {
        System.out.println("traductorController.traducir()");
        System.out.println(this.textoATraducir);

        this.textoATraducir = this.textoATraducir.toLowerCase();
        String[] palabras = this.textoATraducir.split(" ");

        this.seniasPalabras = new ArrayList();
        for (int i = 0; i < palabras.length; i++) {
            Map<String, Object> params = new HashMap<>();
            params.put("nombre", palabras[i].replaceAll("_", " ").toLowerCase());
            this.seniaPalabra = new SeniasPalabras();
            this.seniaPalabra = seniasPalabrasFacade.querySingle("SeniasPalabras.findByNombre", params);
            this.seniasPalabras.add(this.seniaPalabra);
            System.out.println(this.seniasPalabras);
        }

    }

    public String getTextoATraducir() {
        return textoATraducir;
    }

    public void setTextoATraducir(String textoATraducir) {
        this.textoATraducir = textoATraducir;
    }

    public List<SeniasPalabras> getSeniasPalabras() {
        return seniasPalabras;
    }

    public void setSeniasPalabras(List<SeniasPalabras> seniasPalabras) {
        this.seniasPalabras = seniasPalabras;
    }

    public SeniasPalabras getSeniaPalabra() {
        return seniaPalabra;
    }

    public void setSeniaPalabra(SeniasPalabras seniaPalabra) {
        this.seniaPalabra = seniaPalabra;
    }

}
