/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package controladores;

import entidades.Usuario;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

/**
 *
 * @author pc
 */
@Named(value = "menuController")
@ViewScoped
public class MenuController implements Serializable {

    private Usuario userConsulta;
    
    /**
     * Creates a new instance of MenuController
     */
    public MenuController() { }
    
    @PostConstruct
    public void init() { 
        this.userConsulta = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("usuario");
        System.out.println(this.userConsulta);
    }
    
    public void validaAcceso () {
        
    }

    public Usuario getUserConsulta() {
        return userConsulta;
    }

    public void setUserConsulta(Usuario userConsulta) {
        this.userConsulta = userConsulta;
    }
    
}
