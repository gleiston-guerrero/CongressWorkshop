/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package controladores;

import entidades.SeniasPalabras;
import entidades.Usuario;
import facade.SeniasPalabrasFacade;
import java.io.IOException;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.apache.poi.util.IOUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

/**
 *
 * @author dcarvajals
 */
@Named(value = "palabraController")
@ViewScoped
public class PalabraController implements Serializable {

    @EJB
    private SeniasPalabrasFacade seniasPalabrasFacade;

    private UploadedFile file;
    private SeniasPalabras seniasPalabra;
    private List<SeniasPalabras> seniasPalabras;
    private Usuario userConsulta;
    
    private String relPath = "";
    
    /**
     * Creates a new instance of PalabraController
     */
    public PalabraController() { }
    
    @PostConstruct
    public void init () {
        this.userConsulta = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("usuario");
        this.seniasPalabra = new SeniasPalabras();
        this.seniasPalabras = this.seniasPalabrasFacade.findAll();
        
        ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();

        String webContentRoot = ec.getRealPath("/");
        relPath = webContentRoot.replace("\\", "/");
        System.out.println("[REL-PATH]: " + relPath);
    }
    
    public void nuevo () { 
        this.seniasPalabra = new SeniasPalabras();
    }
    
    public void leerDatosGuia(FileUploadEvent event) throws IOException {
            file = event.getFile(); 
            System.out.println(this.file);
        }
    
    public void guardarCambios () { 
        System.out.println("guardarCambios()");
        String path = this.relPath + "\\..\\..\\src\\main\\webapp\\resources\\images\\senias";
        String path2 = this.relPath + "\\resources\\images\\senias";
        
        //String path = "D:\\app_web\\SeniasTraductor\\src\\main\\webapp\\resources\\images\\senias";
        //String path2 = "D:\\app_web\\SeniasTraductor\\target\\SeniasTraductor-1.0\\resources\\images\\senias";
        System.out.println(this.file);
        System.out.println(this.seniasPalabra.getNombre());
        int pos = this.file.getFileName().lastIndexOf(".");
        String ext = this.file.getFileName().substring(pos + 1, this.file.getFileName().length());
        System.out.println(ext);
        try {
            this.seniasPalabra.setNombre(this.seniasPalabra.getNombre().replaceAll(" ", "").toLowerCase());
            this.seniasPalabra.setFechaRegistro(new Date());
            this.seniasPalabra.setImagen(this.seniasPalabra.getNombre().replaceAll(" ", "").toLowerCase()+"."+ ext);
            this.seniasPalabra.setIdUsuario(this.userConsulta);
            this.seniasPalabrasFacade.create(this.seniasPalabra);
            if(this.file.getSize() > 0) {
                crearImagen(IOUtils.toByteArray(this.file.getInputStream()), path, this.seniasPalabra.getNombre().replaceAll(" ", "").toLowerCase() +"."+ ext);
                crearImagen(IOUtils.toByteArray(this.file.getInputStream()), path2, this.seniasPalabra.getNombre().replaceAll(" ", "").toLowerCase() +"."+ ext);
                this.seniasPalabra = null;
                System.out.println("IMAGEN CREADA");
                this.seniasPalabras = this.seniasPalabrasFacade.findAll();
                PrimeFaces.current().executeScript("alert('Imagen creada exitosamente.')");
                PrimeFaces.current().ajax().update("frmListSeniaPalabras:dtSeniaPalabra");
            }
        } catch (IOException ex) {System.out.println("ERROR:" + ex.getMessage());}
        
    }
    
    public void eliminar () {
        System.out.println(this.seniasPalabra.getNombre());
        this.seniasPalabrasFacade.remove(this.seniasPalabra);
        this.seniasPalabras = this.seniasPalabrasFacade.findAll();
        PrimeFaces.current().ajax().update("frmListSeniaPalabras:dtSeniaPalabra");
        
    }
    
    public void crearImagen (byte[] bytes, String rutaFolder, String nombreImg) {
        try {
            Path path = Paths.get(rutaFolder, nombreImg);
            Files.write(path, bytes);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } 
    }

    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }

    public SeniasPalabras getSeniasPalabra() {
        return seniasPalabra;
    }

    public void setSeniasPalabra(SeniasPalabras seniasPalabra) {
        this.seniasPalabra = seniasPalabra;
    }

    public List<SeniasPalabras> getSeniasPalabras() {
        return seniasPalabras;
    }

    public void setSeniasPalabras(List<SeniasPalabras> seniasPalabras) {
        this.seniasPalabras = seniasPalabras;
    }
    
    
    
}
