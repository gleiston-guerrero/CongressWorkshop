/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package controladores;

import entidades.Usuario;
import facade.UsuarioFacade;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.context.FacesContext;

/**
 *
 * @author danny
 */
@Named(value = "usuarioControlador")
@ViewScoped
public class UsuarioControlador implements Serializable {

    @EJB
    private UsuarioFacade usuarioFacade;

    private Usuario usuario;

    /**
     * Creates a new instance of UsuarioControlador
     */
    public UsuarioControlador() {
    }

    @PostConstruct
    public void init() {
        this.usuario = new Usuario();
    }

    public String login() {
        System.out.println("login()");
        String redireccion = "";
        Usuario usuarioConsulta = this.usuarioFacade.validarUsuarioApp(this.usuario.getNombreUsuario(), this.usuario.getContrasenia());
        System.out.println(usuarioConsulta);
        if (usuarioConsulta != null) {
            System.out.println("CREDENCIALES CORRECTAS !!");
            FacesContext.getCurrentInstance().getExternalContext()
                    .getSessionMap().put("usuario", usuarioConsulta);
            redireccion = "/traductor?faces-redirect=true";
        } else {
            System.out.println("CREDENCIALES INCORRECTAS !!");
            redireccion = "";
        }
        return redireccion;
    }

    public String cerrarSesion() {
        FacesContext.getCurrentInstance().getExternalContext()
                .getSessionMap().put("usuario", null);
        return "/traductor?faces-redirect=true";
    }
    
    public String cerrarSesion_() {
        FacesContext.getCurrentInstance().getExternalContext()
                .getSessionMap().put("usuario", null);
        return "/index?faces-redirect=true";
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

}
