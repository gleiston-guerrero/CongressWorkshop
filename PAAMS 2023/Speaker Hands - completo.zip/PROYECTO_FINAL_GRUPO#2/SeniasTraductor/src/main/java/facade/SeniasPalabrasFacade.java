/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import entidades.SeniasPalabras;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import reutilizable.AbstractFacade;

/**
 *
 * @author danny
 */
@Stateless
public class SeniasPalabrasFacade extends AbstractFacade<SeniasPalabras> {

    @PersistenceContext(unitName = "tt.app.seniastraductor")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SeniasPalabrasFacade() {
        super(SeniasPalabras.class);
    }
}
