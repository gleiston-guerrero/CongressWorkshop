/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import entidades.Usuario;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import reutilizable.AbstractFacade;

/**
 *
 * @author danny
 */
@Stateless
public class UsuarioFacade extends AbstractFacade<Usuario> {

    @PersistenceContext(unitName = "tt.app.seniastraductor")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuarioFacade() {
        super(Usuario.class);
    }
    
    public Usuario validarUsuarioApp(String nombre, String contrasenia) {
        System.out.println(nombre);
        System.out.println(contrasenia);
        Query query = this.getEntityManager().createNativeQuery("select * from usuario where nombre_usuario = ? and contrasenia = ?;", Usuario.class);
        query.setParameter(1, nombre);
        query.setParameter(2, contrasenia);
        try {
            return (Usuario) query.getSingleResult();
        } catch (Exception ex) {
            return null;
        }
    }
}
