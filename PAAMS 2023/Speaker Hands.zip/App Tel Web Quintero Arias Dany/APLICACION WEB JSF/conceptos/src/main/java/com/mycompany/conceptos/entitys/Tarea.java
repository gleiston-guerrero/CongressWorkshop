/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.conceptos.entitys;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author danny
 */
@Entity
@Table(catalog = "postgres", schema = "public")
@NamedQueries({
    @NamedQuery(name = "Tarea.findAll", query = "SELECT t FROM Tarea t"),
    @NamedQuery(name = "Tarea.findByConcepts", query = "SELECT t FROM Tarea t WHERE t.concepts = :concepts"),
    @NamedQuery(name = "Tarea.findByDefinicios", query = "SELECT t FROM Tarea t WHERE t.definicios = :definicios")})
public class Tarea implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(nullable = false, length = 50)
    private String concepts;
    @Size(max = 1000)
    @Column(length = 1000)
    private String definicios;

    public Tarea() {
    }

    public Tarea(String concepts) {
        this.concepts = concepts;
    }

    public String getConcepts() {
        return concepts;
    }

    public void setConcepts(String concepts) {
        this.concepts = concepts;
    }

    public String getDefinicios() {
        return definicios;
    }

    public void setDefinicios(String definicios) {
        this.definicios = definicios;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (concepts != null ? concepts.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tarea)) {
            return false;
        }
        Tarea other = (Tarea) object;
        if ((this.concepts == null && other.concepts != null) || (this.concepts != null && !this.concepts.equals(other.concepts))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.conceptos.Tarea[ concepts=" + concepts + " ]";
    }
    
}
